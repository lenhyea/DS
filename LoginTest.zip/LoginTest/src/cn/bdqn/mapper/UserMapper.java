package cn.bdqn.mapper;

import java.util.Map;

import cn.bdqn.pojo.User;

public interface UserMapper {
	public User login(Map<String, Object> map);
}

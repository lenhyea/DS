package cn.bdqn.pojo;

public class User {
	private String username;

	private String pwd;

	private String name;

	private int age;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public User(String username, String pwd, String name, int age) {
		super();
		this.username = username;
		this.pwd = pwd;
		this.name = name;
		this.age = age;
	}

	public User() {
		super();
	}

}

package cn.bdqn.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.bdqn.mapper.UserMapper;
import cn.bdqn.pojo.User;
import cn.bdqn.service.LoginService;

@Service("loginService")
public class LoginServiceImpl implements LoginService {

	@Resource(name = "userMapper")
	private UserMapper mapper;

	@Override
	public User login(String username, String pwd) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("username", username);
		map.put("pwd", pwd);

		System.out.println("impl------------");
		User user = mapper.login(map);
		System.out.println(user);
		return user;
	}

}

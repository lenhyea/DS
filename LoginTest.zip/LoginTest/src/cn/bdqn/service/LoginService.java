package cn.bdqn.service;

import cn.bdqn.pojo.User;

public interface LoginService {
	public User login(String username, String pwd);
}

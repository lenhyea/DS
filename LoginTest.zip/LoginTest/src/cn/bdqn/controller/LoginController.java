package cn.bdqn.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.bdqn.pojo.User;
import cn.bdqn.service.LoginService;

@Controller
public class LoginController {

	@Resource(name = "loginService")
	private LoginService login;

	@RequestMapping("/login")
	public String Login(String username, String pwd, Model model) {
		System.out.println("--------------------");
		User user = login.login(username, pwd);
		model.addAttribute(user);
		System.out.println("===================");

		return user == null ? "index" : "ok";
	}
}
